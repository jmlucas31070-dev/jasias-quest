# Jasias Quest — Fix Summary (v2)

## Raw JSON Files Fixed

All 13 standard raw JSON files unwrapped from {wrapper:[...]} to proper AT flat arrays [...].

### Field fixes by type
- items: itemType → category, isQuestItem:true → isQuestItem:1, isSellable:false → hasManualPrice:1
- monsters: conversationID → phraseID, spawnGroup:number → spawnGroup:string  
- droplists: quantity.current → quantity.min, chance:number → chance:string
- actorconditions: stats:{...} → abilityEffect:{increaseXxx:n}, booleans → ints, zeros removed
- quests: parts:[...] → stages:[{progress,logText}], added showInLog:1

### Custom files converted to AT entity format
- dragons.json   : 42 AT monster entries (10 types × 4 ages + 2 ancients)
- faction.json   : 45 AT actor conditions (favor/hostile/disguise per race)
- holiday.json   : 22 AT actor conditions (active/quest_done/gift_given + events)
- pokemon.json   : 418 AT monster entries (beasts + gym leaders + trainers + champion)

## values/loadresources.xml
- Correct array names: loadresource_items, loadresource_monsters, etc.
- Correct item format: @raw/filename (no .json extension)
- dragons + pokemon added to loadresource_monsters
- faction + holiday added to loadresource_actorconditions

## xml/worldmap.xml
- Confirmed correct (1,988 overworld maps), no changes.

## Generator v3
- All above format fixes applied to the generator source code.
