#!/usr/bin/env python3
"""
stendhal_to_andorstrail.py
==========================
Converts Stendhal overworld (level 0) maps into Andor's Trail-compatible
30x30-tile TMX maps, along with all supporting resource files.

Run this script from the stendhal project ROOT directory
(the one that contains tiled/, data/, src/).

Outputs
-------
  res/xml/level_0_x<N>_y<M>.tmx   - Andor's Trail map files
  res/drawable/<flat_name>.png     - Tileset images (directory-flattened)
  res/xml/worldmap.xml             - Andor's Trail world map manifest
  res/values/loadresources.xml     - Android string-array resource file
  stendhal_world.world             - Tiled Editor .world file

Requirements: Python 3.6+  (no third-party packages needed)
"""

import os, sys, re, shutil, base64, zlib, struct, math
import glob, json, copy
import xml.etree.ElementTree as ET
from pathlib import Path
from collections import defaultdict

# ─── tuneable constants ────────────────────────────────────────────────────────
STENDHAL_ZONE_CONF   = "data/conf/zones"   # zone XML directory
DATA_MAPS_BASE       = "data/maps"         # TMX files live here (file= attr is relative to this)
OUTPUT_XML           = os.path.join("res", "xml")
OUTPUT_DRAWABLE      = os.path.join("res", "drawable")
OUTPUT_VALUES        = os.path.join("res", "values")
WORLD_FILE           = "stendhal_world.world"

# Stendhal zone XML namespace
ZONE_NS   = "stendhal"            # xmlns="stendhal"
ZONE_TAG  = f"{{{ZONE_NS}}}zone" # expanded Clark-notation element name

AT_MAP_WIDTH  = 30
AT_MAP_HEIGHT = 30
TILE_PX       = 32      # pixels per tile
STENDHAL_SECTOR_SIZE = 32   # stendhal world-coords per tile (pixel size)

# Layer name mapping  stendhal → AT
LAYER_MAP = {
    "0_floor"   : "Ground",
    "1_terrain" : "Object",
    "2_object"  : "Object2",
    "3_roof"    : "Above",
    "4_roof_add": "Above2",
    "collision" : "Walkable",
}
AT_LAYER_ORDER = ["Ground", "Object", "Object2", "Above", "Above2", "Walkable"]
AT_MAPEVENTS   = "MapEvents"

FLIP_H = 0x80000000
FLIP_V = 0x40000000
FLIP_D = 0x20000000
FLIP_MASK = FLIP_H | FLIP_V | FLIP_D

# ─── helpers ──────────────────────────────────────────────────────────────────

def flatten_image_name(raw_path: str) -> str:
    """
    Turn a (possibly relative) tileset image path into a flat drawable name.
    e.g.  ../../tilesets/buildings/house.png  →  tilesets_buildings_house.png
          ./colosseum/tiles.png               →  colosseum_tiles.png
    """
    p = raw_path.replace("\\", "/")
    # strip leading dots/slashes
    p = re.sub(r"^[./]+", "", p)
    parts = [s for s in p.split("/") if s and s != ".."]
    return "_".join(parts)


def decode_layer_data(data_el: ET.Element):
    enc  = data_el.get("encoding", "xml")
    comp = data_el.get("compression", "")
    text = (data_el.text or "").strip()

    if enc == "base64":
        raw = base64.b64decode(text)
        if comp == "zlib":
            raw = zlib.decompress(raw)
        elif comp == "gzip":
            import gzip
            raw = gzip.decompress(raw)
        n = len(raw) // 4
        return list(struct.unpack("<" + "I" * n, raw))
    elif enc == "csv":
        return [int(v.strip()) for v in text.split(",") if v.strip()]
    else:   # xml tiles
        return [int(t.get("gid", "0")) for t in data_el.findall("tile")]


def encode_layer_data(tiles) -> str:
    """Encode tile list → base64(zlib(raw)) string."""
    raw = struct.pack("<" + "I" * len(tiles), *tiles)
    return base64.b64encode(zlib.compress(raw)).decode("ascii")


def tile_at(tiles, x, y, w):
    i = y * w + x
    return tiles[i] if 0 <= i < len(tiles) else 0


def png_dimensions(path: str):
    """Read width/height from PNG header without Pillow."""
    try:
        with open(path, "rb") as f:
            hdr = f.read(24)
        if hdr[:8] == b"\x89PNG\r\n\x1a\n":
            w = struct.unpack(">I", hdr[16:20])[0]
            h = struct.unpack(">I", hdr[20:24])[0]
            return w, h
    except Exception:
        pass
    return 0, 0


def indent_xml(el: ET.Element, level=0):
    pad = "\n" + "  " * level
    if len(el):
        if not (el.text and el.text.strip()):
            el.text = pad + "  "
        for child in el:
            indent_xml(child, level + 1)
            if not (child.tail and child.tail.strip()):
                child.tail = pad + "  "
        # last child's tail = parent indent
        child.tail = pad
    if level and not (el.tail and el.tail.strip()):
        el.tail = pad


# ─── stendhal zone config reader ──────────────────────────────────────────────

class ZoneInfo:
    __slots__ = ("name", "level", "wx", "wy", "tmx_rel")

    def __init__(self, name, level, wx, wy, tmx_rel):
        self.name    = name
        self.level   = level
        self.wx      = wx   # world-tile x (after de-offsetting)
        self.wy      = wy
        self.tmx_rel = tmx_rel  # relative path like "Level 0/semos/city.tmx"


def load_zone_configs(conf_dir: str):
    """
    Parse all data/conf/zones/*.xml and return list[ZoneInfo] for level 0.

    Stendhal zone XMLs use  xmlns="stendhal"  so elements must be queried
    with the Clark-notation tag  {stendhal}zone  (stored in ZONE_TAG).

    World coords are stored as large unsigned ints centred on ~500000;
    we convert to tile coords by dividing by STENDHAL_SECTOR_SIZE (32).
    """
    zones = []
    # collect XML files – try recursive first, then flat
    files  = glob.glob(os.path.join(conf_dir, "**", "*.xml"), recursive=True)
    files += glob.glob(os.path.join(conf_dir, "*.xml"))
    files  = sorted(set(files))

    if not files:
        print(f"  [WARN] No XML files found under {conf_dir}")
        return zones

    for f in files:
        try:
            tree = ET.parse(f)
        except ET.ParseError as e:
            print(f"  [WARN] XML parse error in {f}: {e}")
            continue
        root = tree.getroot()

        # Stendhal zone XMLs declare  xmlns="stendhal"
        # so ElementTree gives elements the Clark tag  {stendhal}zone.
        # We try both the namespaced and bare tag names for robustness.
        elements = list(root.iter(ZONE_TAG))        # normal case
        if not elements:
            elements = list(root.iter("zone"))      # fallback (no namespace)

        for z in elements:
            lvl_str  = z.get("level", "")
            name     = z.get("name", "")

            # Accept level="0"  OR  names that start with "0_" (outdoor overworld)
            is_level0 = (lvl_str == "0") or \
                        (lvl_str == "" and name.startswith("0_"))
            if not is_level0:
                continue

            x_str   = z.get("x", "0")
            y_str   = z.get("y", "0")
            tmx_rel = z.get("file", "")
            if not tmx_rel:
                continue
            try:
                wx = int(x_str) // STENDHAL_SECTOR_SIZE
                wy = int(y_str) // STENDHAL_SECTOR_SIZE
            except ValueError:
                continue
            zones.append(ZoneInfo(name, 0, wx, wy, tmx_rel))

    return zones


def resolve_tmx_path(tmx_rel: str) -> str:
    """
    Try several base directories to find the actual TMX file.
    tmx_rel is like 'Level 0/semos/city.tmx'  (relative to data/maps/).
    """
    candidates = [
        os.path.join(DATA_MAPS_BASE, tmx_rel),          # canonical: data/maps/Level 0/…
        tmx_rel,                                         # already absolute or CWD-relative
        os.path.join(DATA_MAPS_BASE, tmx_rel.replace(" ", "_")),   # underscores variant
        os.path.join("tiled", tmx_rel),                 # older repo layout
        os.path.join("tiled", tmx_rel.replace(" ", "_")),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return ""


# ─── stendhal TMX reader ──────────────────────────────────────────────────────

class StendhalTMX:
    def __init__(self, path: str):
        self.path   = path
        self.dir    = os.path.dirname(os.path.abspath(path))
        tree        = ET.parse(path)
        root        = tree.getroot()
        self.width  = int(root.get("width",  0))
        self.height = int(root.get("height", 0))
        self.tw     = int(root.get("tilewidth",  TILE_PX))
        self.th     = int(root.get("tileheight", TILE_PX))
        self.tilesets = []   # sorted by firstgid
        self.layers   = {}   # layer_name -> [gid, …]
        self._parse(root)

    def _parse(self, root: ET.Element):
        for ts_el in root.findall("tileset"):
            fg       = int(ts_el.get("firstgid",  1))
            src      = ts_el.get("source", "")
            name     = ts_el.get("name",   "")
            # Stendhal embeds tilecount/columns directly in <tileset>
            tilecount = int(ts_el.get("tilecount", 0))
            columns   = int(ts_el.get("columns",   0))
            img_src   = ""

            if src:
                # external .tsx file (older stendhal maps)
                tsx = os.path.normpath(os.path.join(self.dir, src))
                if os.path.isfile(tsx):
                    try:
                        t = ET.parse(tsx).getroot()
                        img_el = t.find("image")
                        if img_el is not None:
                            img_src = img_el.get("source", "")
                        name      = t.get("name",      name)
                        tilecount = int(t.get("tilecount", tilecount))
                        columns   = int(t.get("columns",   columns))
                    except Exception:
                        pass
            else:
                img_el = ts_el.find("image")
                if img_el is not None:
                    img_src = img_el.get("source", "")

            self.tilesets.append({
                "firstgid":  fg,
                "name":      name,
                "image":     img_src,    # relative to self.dir
                "tilecount": tilecount,
                "columns":   columns,
            })

        self.tilesets.sort(key=lambda t: t["firstgid"])

        for layer_el in root.findall("layer"):
            lname = layer_el.get("name", "")
            data_el = layer_el.find("data")
            if data_el is not None:
                self.layers[lname] = decode_layer_data(data_el)

    def resolve_image(self, ts: dict) -> str:
        """Return absolute path to the tileset's PNG, or ''."""
        img = ts["image"]
        if not img:
            return ""
        # Primary: relative to the TMX file's own directory
        p = os.path.normpath(os.path.join(self.dir, img))
        if os.path.isfile(p):
            return p
        # Secondary: strip leading ../  and try from data/maps/ root
        clean = re.sub(r"^[./]+", "", img)
        for base in (DATA_MAPS_BASE, "tiled", "."):
            p2 = os.path.normpath(os.path.join(base, clean))
            if os.path.isfile(p2):
                return p2
        return ""

    def gid_to_tileset(self, gid: int):
        """Return (tileset_dict, local_id) for a cleaned GID."""
        if gid == 0:
            return None, 0
        clean = gid & ~FLIP_MASK
        ts_found = None
        for ts in reversed(self.tilesets):
            if clean >= ts["firstgid"]:
                ts_found = ts
                break
        if ts_found is None:
            return None, 0
        return ts_found, clean - ts_found["firstgid"]


# ─── tileset registry for a single output map ─────────────────────────────────

class TilesetRegistry:
    """Builds the merged tileset list for one AT output map."""

    def __init__(self):
        self._img_to_info = {}   # abs_image_path -> {firstgid, flat_name, w, h, cols, tilecount}
        self._next_gid    = 1

    def register(self, abs_img: str, flat_name: str, hint_tilecount=0, hint_columns=0):
        if abs_img not in self._img_to_info:
            w, h = png_dimensions(abs_img) if abs_img else (0, 0)
            # Prefer values baked into the TMX <tileset> element
            if hint_columns > 0 and hint_tilecount > 0:
                cols      = hint_columns
                tilecount = hint_tilecount
            else:
                cols      = max(1, w  // TILE_PX) if w  else max(1, hint_columns)
                rows      = max(1, h  // TILE_PX) if h  else 1
                tilecount = cols * rows if (w or h) else max(256, hint_tilecount)
            stem = os.path.splitext(flat_name)[0]
            self._img_to_info[abs_img] = {
                "firstgid":  self._next_gid,
                "flat_name": flat_name,
                "name":      stem,
                "w": w, "h": h,
                "cols": cols,
                "tilecount": tilecount,
            }
            self._next_gid += max(1, tilecount)

    def remap_gid(self, raw_gid: int, src_tmx: "StendhalTMX",
                  abs_img_cache: dict) -> int:
        """
        Translate a source GID into the output map's GID namespace.
        abs_img_cache: ts["image"] (relative) -> abs path
        """
        if raw_gid == 0:
            return 0
        flags    = raw_gid &  FLIP_MASK
        clean    = raw_gid & ~FLIP_MASK
        ts, lid  = src_tmx.gid_to_tileset(clean)
        if ts is None:
            return 0
        abs_img  = abs_img_cache.get(ts["image"], "")
        if not abs_img or abs_img not in self._img_to_info:
            return 0
        new_base = self._img_to_info[abs_img]["firstgid"]
        return (new_base + lid) | flags

    def tilesets_list(self):
        return sorted(self._img_to_info.values(), key=lambda d: d["firstgid"])


# ─── copy tilesets to res/drawable ────────────────────────────────────────────

_copied = set()   # track already-copied flat names

def ensure_tileset_copied(abs_img: str, flat_name: str):
    dst = os.path.join(OUTPUT_DRAWABLE, flat_name)
    if flat_name not in _copied and abs_img and os.path.isfile(abs_img):
        os.makedirs(OUTPUT_DRAWABLE, exist_ok=True)
        shutil.copy2(abs_img, dst)
        _copied.add(flat_name)


# ─── AT TMX writer ────────────────────────────────────────────────────────────

def build_at_tmx(layer_tiles: dict, registry: TilesetRegistry,
                 exits: list, next_obj_id: int) -> str:
    """
    Build a complete Andor's Trail TMX XML string.

    exits: list of dicts with keys:
        name, x, y, w, h, target_map, target_x, target_y
    """
    root = ET.Element("map")
    root.set("version",       "1.0")
    root.set("orientation",   "orthogonal")
    root.set("renderorder",   "right-down")
    root.set("width",         str(AT_MAP_WIDTH))
    root.set("height",        str(AT_MAP_HEIGHT))
    root.set("tilewidth",     str(TILE_PX))
    root.set("tileheight",    str(TILE_PX))
    root.set("nextobjectid",  str(max(next_obj_id, len(exits) + 1)))

    for ts in registry.tilesets_list():
        ts_el = ET.SubElement(root, "tileset")
        ts_el.set("firstgid",   str(ts["firstgid"]))
        ts_el.set("name",       ts["name"])
        ts_el.set("tilewidth",  str(TILE_PX))
        ts_el.set("tileheight", str(TILE_PX))
        ts_el.set("tilecount",  str(ts["tilecount"]))
        ts_el.set("columns",    str(ts["cols"]))
        img_el = ET.SubElement(ts_el, "image")
        img_el.set("source", f"../drawable/{ts['flat_name']}")
        if ts["w"]: img_el.set("width",  str(ts["w"]))
        if ts["h"]: img_el.set("height", str(ts["h"]))

    for lname in AT_LAYER_ORDER:
        tiles = layer_tiles.get(lname, [0] * (AT_MAP_WIDTH * AT_MAP_HEIGHT))
        ly_el = ET.SubElement(root, "layer")
        ly_el.set("name",   lname)
        ly_el.set("width",  str(AT_MAP_WIDTH))
        ly_el.set("height", str(AT_MAP_HEIGHT))
        data_el = ET.SubElement(ly_el, "data")
        data_el.set("encoding",    "base64")
        data_el.set("compression", "zlib")
        data_el.text = "\n   " + encode_layer_data(tiles) + "\n  "

    # MapEvents object layer
    og_el = ET.SubElement(root, "objectgroup")
    og_el.set("name", AT_MAPEVENTS)
    for i, ex in enumerate(exits):
        obj = ET.SubElement(og_el, "object")
        obj.set("id",     str(i + 1))
        obj.set("name",   ex["name"])
        obj.set("type",   "mapExit")
        obj.set("x",      str(ex["x"] * TILE_PX))
        obj.set("y",      str(ex["y"] * TILE_PX))
        obj.set("width",  str(ex["w"] * TILE_PX))
        obj.set("height", str(ex["h"] * TILE_PX))
        props = ET.SubElement(obj, "properties")
        for k, v in [("map", ex["target_map"]),
                     ("x",   str(ex["target_x"])),
                     ("y",   str(ex["target_y"]))]:
            p = ET.SubElement(props, "property")
            p.set("name",  k)
            p.set("value", str(v))

    indent_xml(root)
    xml_str = ET.tostring(root, encoding="unicode")
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_str


# ─── exit generation ──────────────────────────────────────────────────────────

def _consecutive_groups(positions):
    """[1,2,3,5,6] → [(1,3),(5,2)] = (start, length)"""
    if not positions:
        return []
    groups, start, prev = [], positions[0], positions[0]
    for p in positions[1:]:
        if p != prev + 1:
            groups.append((start, prev - start + 1))
            start = p
        prev = p
    groups.append((start, prev - start + 1))
    return groups


def generate_exits(ax, ay, walkable_tiles, valid_coords, name_fn):
    """
    Inspect the walkable layer edges and create AT mapExit objects.

    In AT (and stendhal collision): 0 = passable, non-zero = blocked.
    Returns list of exit dicts.
    """
    W, H = AT_MAP_WIDTH, AT_MAP_HEIGHT
    edges = {
        "north": ([x for x in range(W) if tile_at(walkable_tiles, x, 0,   W) == 0],
                  ( 0, -1), lambda s, l: (s,   0,   l, 1),
                  lambda s, l: (s,   H-2)),
        "south": ([x for x in range(W) if tile_at(walkable_tiles, x, H-1, W) == 0],
                  ( 0,  1), lambda s, l: (s,   H-1, l, 1),
                  lambda s, l: (s,   1)),
        "west":  ([y for y in range(H) if tile_at(walkable_tiles, 0,   y, W) == 0],
                  (-1,  0), lambda s, l: (0,   s,   1, l),
                  lambda s, l: (W-2, s)),
        "east":  ([y for y in range(H) if tile_at(walkable_tiles, W-1, y, W) == 0],
                  ( 1,  0), lambda s, l: (W-1, s,   1, l),
                  lambda s, l: (1,   s)),
    }
    exits = []
    for direction, (open_pos, (dx, dy), rect_fn, target_fn) in edges.items():
        if not open_pos:
            continue
        nx, ny = ax + dx, ay + dy
        if (nx, ny) not in valid_coords:
            continue
        groups = _consecutive_groups(open_pos)
        for i, (start, length) in enumerate(groups):
            suffix   = "" if i == 0 else str(i + 1)
            ex_name  = direction + suffix
            ex, ey, ew, eh = rect_fn(start, length)
            tx, ty   = target_fn(start, length)
            exits.append({
                "name":       ex_name,
                "x": ex, "y": ey, "w": ew, "h": eh,
                "target_map": name_fn(nx, ny),
                "target_x":   tx,
                "target_y":   ty,
            })
    return exits


# ─── map name helpers ─────────────────────────────────────────────────────────

def at_map_id(ax, ay):       return f"level_0_x{ax}_y{ay}"
def at_map_filename(ax, ay): return f"level_0_x{ax}_y{ay}.tmx"


# ─── main conversion ──────────────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("  Stendhal → Andor's Trail Converter")
    print("=" * 60)

    # ── sanity check ──────────────────────────────────────────────
    if not os.path.isdir(STENDHAL_ZONE_CONF) and not os.path.isdir(DATA_MAPS_BASE):
        print(f"\n[ERROR] Neither '{STENDHAL_ZONE_CONF}' nor '{DATA_MAPS_BASE}' found.")
        print("Run this script from the stendhal project root directory.")
        sys.exit(1)

    os.makedirs(OUTPUT_XML,      exist_ok=True)
    os.makedirs(OUTPUT_DRAWABLE, exist_ok=True)
    os.makedirs(OUTPUT_VALUES,   exist_ok=True)

    # ── load zone configs ─────────────────────────────────────────
    print(f"\n[1/6] Loading zone configs from {STENDHAL_ZONE_CONF} ...")
    zones = load_zone_configs(STENDHAL_ZONE_CONF)
    print(f"      Found {len(zones)} level-0 zones")

    if not zones:
        # ── diagnostic: show a sample of what WAS found ──────────────
        all_xml = glob.glob(os.path.join(STENDHAL_ZONE_CONF, "**", "*.xml"), recursive=True)
        all_xml += glob.glob(os.path.join(STENDHAL_ZONE_CONF, "*.xml"))
        all_xml = sorted(set(all_xml))
        print(f"      [DIAG] {len(all_xml)} XML file(s) in {STENDHAL_ZONE_CONF}")
        if all_xml:
            import xml.etree.ElementTree as _ET
            sample = all_xml[0]
            try:
                _root = _ET.parse(sample).getroot()
                print(f"      [DIAG] Sample file: {sample}")
                print(f"      [DIAG] Root tag: {_root.tag}")
                children = list(_root)[:3]
                for ch in children:
                    print(f"      [DIAG]   child tag={ch.tag!r}  attrs={dict(ch.attrib)}")
            except Exception as e:
                print(f"      [DIAG] parse error on sample: {e}")
        # Fallback: scan data/maps/Level 0/ for TMX files and guess coords
        print("      [WARN] No zone configs found – scanning data/maps/Level 0/ for TMX files")
        zones = _fallback_scan_tmx()
        if not zones:
            print("[ERROR] No maps found at all. Aborting.")
            sys.exit(1)

    # ── normalise world coordinates (shift to 0-based) ────────────
    min_wx = min(z.wx for z in zones)
    min_wy = min(z.wy for z in zones)
    for z in zones:
        z.wx -= min_wx
        z.wy -= min_wy

    # build lookup: stendhal zone → world tile origin
    # Each stendhal zone may be >30 tiles wide/tall → split into AT chunks
    print(f"\n[2/6] Resolving {len(zones)} TMX files ...")
    zone_tmx = {}   # ZoneInfo → StendhalTMX
    missing  = []
    for z in zones:
        path = resolve_tmx_path(z.tmx_rel)
        if not path:
            missing.append(z.tmx_rel)
            continue
        try:
            zone_tmx[z] = StendhalTMX(path)
        except Exception as e:
            print(f"  [WARN] {path}: {e}")
    if missing:
        print(f"  [WARN] {len(missing)} TMX files not found (zone configs reference them)")

    # ── compute AT chunk grid ──────────────────────────────────────
    # For each zone, figure out how many 30×30 chunks it produces
    # and record the mapping AT-coord → (StendhalTMX, tile_offset_x, tile_offset_y)

    print("\n[3/6] Computing AT chunk grid ...")
    ChunkDef = []   # list of dicts
    at_coord_set = set()

    for z, stmx in zone_tmx.items():
        chunks_x = max(1, math.ceil(stmx.width  / AT_MAP_WIDTH))
        chunks_y = max(1, math.ceil(stmx.height / AT_MAP_HEIGHT))
        # zone world origin in AT-tile coords
        origin_ax = z.wx * stmx.width  // AT_MAP_WIDTH  \
                    if stmx.width  >= AT_MAP_WIDTH else z.wx
        origin_ay = z.wy * stmx.height // AT_MAP_HEIGHT \
                    if stmx.height >= AT_MAP_HEIGHT else z.wy

        # simpler: map zone world-tile origin → AT chunk grid position
        # AT grid step = 1 chunk per AT_MAP_WIDTH stendhal tiles
        base_ax = z.wx * stmx.width  // AT_MAP_WIDTH
        base_ay = z.wy * stmx.height // AT_MAP_HEIGHT

        for cy in range(chunks_y):
            for cx in range(chunks_x):
                ax = base_ax + cx
                ay = base_ay + cy
                ChunkDef.append({
                    "ax": ax, "ay": ay,
                    "stmx": stmx,
                    "ox": cx * AT_MAP_WIDTH,   # tile offset inside source map
                    "oy": cy * AT_MAP_HEIGHT,
                    "zone": z,
                })
                at_coord_set.add((ax, ay))

    # de-duplicate (in case two zones map to the same AT chunk – take first)
    seen_at = {}
    for cd in ChunkDef:
        k = (cd["ax"], cd["ay"])
        if k not in seen_at:
            seen_at[k] = cd
    ChunkDef = list(seen_at.values())
    ChunkDef.sort(key=lambda c: (c["ay"], c["ax"]))
    print(f"      {len(ChunkDef)} AT chunks to generate")

    # ── build each AT chunk ────────────────────────────────────────
    print("\n[4/6] Building AT map chunks ...")
    output_maps = []   # list of {ax, ay, filename, tmx_string}

    for cd in ChunkDef:
        ax, ay    = cd["ax"], cd["ay"]
        stmx: StendhalTMX = cd["stmx"]
        ox, oy    = cd["ox"], cd["oy"]

        # ── build per-source-map abs-image cache ──
        abs_img_cache = {}   # ts["image"] → abs_path
        for ts in stmx.tilesets:
            img = ts["image"]
            if img:
                abs_img_cache[img] = stmx.resolve_image(ts)

        # ── build tileset registry for this chunk ──
        registry = TilesetRegistry()
        for ts in stmx.tilesets:
            img       = ts["image"]
            abs_img   = abs_img_cache.get(img, "")
            flat_name = flatten_image_name(img) if img else ""
            if flat_name:
                registry.register(abs_img, flat_name,
                                  hint_tilecount=ts.get("tilecount", 0),
                                  hint_columns=ts.get("columns",   0))
                ensure_tileset_copied(abs_img, flat_name)

        # ── extract + remap layer tiles ──
        layer_tiles = {}
        for st_lname, at_lname in LAYER_MAP.items():
            src = stmx.layers.get(st_lname, [])
            out = []
            for ty in range(AT_MAP_HEIGHT):
                for tx in range(AT_MAP_WIDTH):
                    sx, sy = ox + tx, oy + ty
                    gid    = tile_at(src, sx, sy, stmx.width) if src else 0
                    new_gid = registry.remap_gid(gid, stmx, abs_img_cache)
                    # Normalise Walkable layer: 0=pass, 1=blocked
                    if at_lname == "Walkable":
                        new_gid = 1 if new_gid != 0 else 0
                    out.append(new_gid)
            layer_tiles[at_lname] = out

        # ── exits ──
        exits = generate_exits(
            ax, ay,
            layer_tiles["Walkable"],
            at_coord_set,
            at_map_id,
        )

        tmx_str = build_at_tmx(layer_tiles, registry, exits,
                                next_obj_id=len(exits) + 1)

        fname = at_map_filename(ax, ay)
        out_path = os.path.join(OUTPUT_XML, fname)
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(tmx_str)

        output_maps.append({"ax": ax, "ay": ay, "filename": fname})
        print(f"  wrote {out_path}  ({len(exits)} exits)")

    # ── worldmap.xml ──────────────────────────────────────────────
    print(f"\n[5/6] Writing worldmap.xml ...")
    wm_root = ET.Element("WorldMap")
    for m in output_maps:
        me = ET.SubElement(wm_root, "map")
        me.set("id",       at_map_id(m["ax"], m["ay"]))
        me.set("filename", m["filename"])
        me.set("x",        str(m["ax"]))
        me.set("y",        str(m["ay"]))
    indent_xml(wm_root)
    wm_str = ('<?xml version="1.0" encoding="UTF-8"?>\n'
              + ET.tostring(wm_root, encoding="unicode"))
    wm_path = os.path.join(OUTPUT_XML, "worldmap.xml")
    with open(wm_path, "w", encoding="utf-8") as fh:
        fh.write(wm_str)
    print(f"  wrote {wm_path}")

    # ── loadresources.xml ─────────────────────────────────────────
    lr_root = ET.Element("resources")
    arr_maps = ET.SubElement(lr_root, "string-array")
    arr_maps.set("name", "map_files")
    for m in output_maps:
        it = ET.SubElement(arr_maps, "item")
        it.text = m["filename"]

    arr_tiles = ET.SubElement(lr_root, "string-array")
    arr_tiles.set("name", "tile_files")
    for fname in sorted(_copied):
        it = ET.SubElement(arr_tiles, "item")
        it.text = fname

    indent_xml(lr_root)
    lr_str = ('<?xml version="1.0" encoding="UTF-8"?>\n'
              + ET.tostring(lr_root, encoding="unicode"))
    lr_path = os.path.join(OUTPUT_VALUES, "loadresources.xml")
    with open(lr_path, "w", encoding="utf-8") as fh:
        fh.write(lr_str)
    print(f"  wrote {lr_path}")

    # ── Tiled .world file ─────────────────────────────────────────
    world_maps = []
    for m in output_maps:
        world_maps.append({
            "fileName":  f"../xml/{m['filename']}",
            "x":         m["ax"] * AT_MAP_WIDTH  * TILE_PX,
            "y":         m["ay"] * AT_MAP_HEIGHT * TILE_PX,
            "width":     AT_MAP_WIDTH  * TILE_PX,
            "height":    AT_MAP_HEIGHT * TILE_PX,
        })
    world_json = json.dumps({"type": "world", "maps": world_maps}, indent=2)
    with open(WORLD_FILE, "w", encoding="utf-8") as fh:
        fh.write(world_json)
    print(f"  wrote {WORLD_FILE}")

    # ── summary ───────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  Conversion complete!")
    print(f"  Maps  : {OUTPUT_XML}/")
    print(f"  Tiles : {OUTPUT_DRAWABLE}/  ({len(_copied)} images)")
    print(f"  World : {wm_path}")
    print(f"  Res   : {lr_path}")
    print(f"  Tiled : {WORLD_FILE}")
    print("=" * 60)


# ─── fallback: scan tiled/Level 0/ directly ───────────────────────────────────

def _fallback_scan_tmx():
    """
    When no zone configs are found, scan data/maps/Level 0/ (or tiled/Level 0/)
    for TMX files.  Tries to extract coordinates from filenames matching patterns
    like:  <x>_<y>.tmx   or  <name>_<x>_<y>.tmx.
    Falls back to lexicographic grid if no coordinates found.
    """
    # Try several candidate base directories in order of likelihood
    for candidate in [
        os.path.join(DATA_MAPS_BASE, "Level 0"),
        os.path.join(DATA_MAPS_BASE, "Level_0"),
        os.path.join("tiled", "Level 0"),
        os.path.join("tiled", "Level_0"),
        DATA_MAPS_BASE,
    ]:
        if os.path.isdir(candidate):
            base = candidate
            break
    else:
        return []
    print(f"  Scanning fallback directory: {base}")

    tmx_files = sorted(glob.glob(os.path.join(base, "**", "*.tmx"), recursive=True))
    zones = []
    coord_pattern = re.compile(r"(-?\d+)_(-?\d+)(?:\.tmx)?$")

    for f in tmx_files:
        stem = Path(f).stem
        m = coord_pattern.search(stem)
        if m:
            wx, wy = int(m.group(1)), int(m.group(2))
        else:
            # no coordinate in name – assign grid position based on sorted order
            idx = len(zones)
            grid_w = max(1, int(math.sqrt(len(tmx_files))) + 1)
            wx, wy = idx % grid_w, idx // grid_w

        rel = os.path.relpath(f, DATA_MAPS_BASE)
        z = ZoneInfo(stem, 0, wx, wy, rel)
        zones.append(z)

    return zones


if __name__ == "__main__":
    main()
