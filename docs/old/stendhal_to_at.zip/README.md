# Stendhal → Andor's Trail Map Converter

Converts the **Stendhal RPG overworld (level 0)** maps into
[Andor's Trail](https://andorstrail.com)-compatible 30×30-tile TMX maps,
along with all auxiliary resource files.

---

## Requirements

| Requirement | Notes |
|---|---|
| **Python 3.6+** | No third-party packages needed (stdlib only) |
| **Stendhal source tree** | Full Git clone of [arianne/stendhal](https://github.com/arianne/stendhal) |

---

## Setup — get the Stendhal source

```bash
git clone https://github.com/arianne/stendhal.git
cd stendhal
```

The relevant directories inside the stendhal repo are:

| Path | What's inside |
|---|---|
| `tiled/Level 0/` | All level-0 (overworld) TMX map files |
| `tiled/` sub-directories | Tileset `.tsx` files and `.png` images |
| `data/conf/zones/` | Zone configuration XMLs (world coordinates) |

---

## Installation — copy the script

Copy `stendhal_to_andorstrail.py` into the **root** of the stendhal
repository (the directory that contains `tiled/`, `data/`, `src/`, etc.):

```
stendhal/
├── data/
│   └── conf/
│       └── zones/          ← zone coordinate XMLs
├── tiled/
│   └── Level 0/            ← TMX source maps
│       ├── athor/
│       ├── nalwor/
│       ├── semos/
│       └── ...
├── stendhal_to_andorstrail.py   ← PUT THE SCRIPT HERE
└── ...
```

---

## Running the script

From the **stendhal root directory** (important!):

```bash
python3 stendhal_to_andorstrail.py
```

The script will print progress for every map it processes.
A typical run processes ~150–200 zones and takes 30–120 seconds
depending on disk speed.

### Expected output directories

```
stendhal/
├── res/
│   ├── xml/
│   │   ├── level_0_x0_y0.tmx
│   │   ├── level_0_x0_y1.tmx
│   │   ├── ...
│   │   └── worldmap.xml
│   ├── drawable/
│   │   ├── tiled_tilesets_building_decoration_arrows.png
│   │   ├── tiled_tilesets_nature_trees.png
│   │   └── ...  (all tileset images, flat-named)
│   └── values/
│       └── loadresources.xml
└── stendhal_world.world
```

---

## Output files explained

### `res/xml/level_0_x<N>_y<M>.tmx`

One AT-compatible TMX per 30×30-tile chunk.  Each file contains:

| Layer | Source stendhal layer | Description |
|---|---|---|
| `Ground`   | `0_floor`    | Base terrain |
| `Object`   | `1_terrain`  | Terrain details |
| `Object2`  | `2_object`   | Decorations / objects |
| `Above`    | `3_roof`     | Roof / canopy |
| `Above2`   | `4_roof_add` | Extra roof layer |
| `Walkable` | `collision`  | 0=passable, 1=blocked |
| `MapEvents`| (generated)  | Exit objects (see below) |

All tile layers use **base64 + zlib compression**, matching the AT template.

#### Tileset paths
All tilesets are referenced as `../drawable/<flat_name>.png` so they resolve
correctly from `res/xml/` to `res/drawable/`.

#### Exit objects (MapEvents layer)
The script inspects the `Walkable` layer edges.  Every run of open (passable)
tiles on a map edge that borders an existing neighbouring map gets a
`mapExit` object:

- Named `north`, `south`, `east`, `west`
- Multiple openings on the same edge: `north2`, `north3`, …
- Target map is the adjacent `level_0_x…_y….tmx`
- Target x/y place the player one tile inside the destination map

Maps on the outer boundary of the world (no neighbour) receive no exit
on that edge.

### `res/xml/worldmap.xml`

Lists every generated map with its AT grid coordinates:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<WorldMap>
  <map id="level_0_x0_y0" filename="level_0_x0_y0.tmx" x="0" y="0" />
  <map id="level_0_x1_y0" filename="level_0_x1_y0.tmx" x="1" y="0" />
  ...
</WorldMap>
```

### `res/values/loadresources.xml`

Android `string-array` resource file listing all maps and tilesets:

```xml
<resources>
  <string-array name="map_files">
    <item>level_0_x0_y0.tmx</item>
    ...
  </string-array>
  <string-array name="tile_files">
    <item>tiled_tilesets_nature_trees.png</item>
    ...
  </string-array>
</resources>
```

### `stendhal_world.world`

Tiled Editor `.world` file (JSON).  Open it in **Tiled ≥ 1.5** to view the
entire converted world as an infinite map.  Each chunk is placed at:

```
pixel_x = ax × 30 × 32
pixel_y = ay × 30 × 32
```

---

## Tileset naming convention

Tileset PNG files are copied to `res/drawable/` with all directory separators
replaced by underscores, and any leading `./` or `../` removed:

| Original path (relative to TMX) | Flat drawable name |
|---|---|
| `../../tilesets/buildings/house.png` | `tilesets_buildings_house.png` |
| `./colosseum/tiles.png` | `colosseum_tiles.png` |
| `../logic/collision.png` | `logic_collision.png` |

---

## Large maps (> 30×30)

Some stendhal zones (e.g. `0_semos_plain_n` is 96×96 tiles) are larger than
the AT 30×30 grid.  The script automatically splits them into multiple
`level_0_x<N>_y<M>.tmx` chunks and generates cross-chunk exits between them.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `[ERROR] Neither … found` | Run the script from the stendhal **root**, not a sub-directory |
| `[WARN] Tileset image not found` | Some internal/abstract zones reference tilesets not included in the repo – those tiles will appear blank |
| Missing interior maps | By design: only **level 0** (outdoor overworld) maps are converted |
| Tiled shows blank tiles | Verify `res/drawable/` contains the PNG referenced in the TMX `<image source=…>` |

---

## Integrating into an Andor's Trail project

1. Copy `res/xml/*.tmx` and `res/xml/worldmap.xml` to your AT project's
   `AndorsTrail/res/xml/` directory.
2. Copy `res/drawable/*.png` to `AndorsTrail/res/drawable/`.
3. Merge `res/values/loadresources.xml` entries into your AT project's
   `AndorsTrail/res/values/loadresources.xml`.
4. Open `stendhal_world.world` in Tiled to browse and edit the world.

---

## Licence notes

The Stendhal maps and tilesets are released under the
[GNU GPL v2](https://github.com/arianne/stendhal/blob/master/LICENSE.txt)
and various CC licences.  Check the stendhal repository for full attribution.
This conversion script itself is provided as-is with no warranty.
