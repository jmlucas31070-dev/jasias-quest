# Andor's Trail Extended Content Pack v5
## Developer Reference

### Format Compliance
All JSON files in this pack comply with the Andor's Trail content format specification:
- **Items**: names and descriptions are plain text strings; displaytype field used instead of isQuestItem; equipment stats in equipEffect; iconID uses "spritesheetname:linearIndex" format
- **Monsters/NPCs**: name is plain text; all stats are top-level fields; attackDamage replaces damagePotential
- **Conversations**: message is plain text; replies use nextPhraseID + requires[]; rewards use AT rewardType/rewardID/value
- **Quests**: name and logText are plain text strings
- **Actor conditions**: name is plain text; category field is always set
- **Droplists**: chance is always a string (e.g. "100")
- **No @string/ references** anywhere in JSON content files

### What's Included

| Category | Count |
|---|---|
| TMX Map Files | 29 |
| JSON Data Files | 7 |
| Regions | 23 |
| Unique Items | 600+ |
| Unique Monsters/NPCs | 900+ |
| Quests | 200+ |
| Conversations | 600+ |
| Actor Conditions | 200+ |
| Astral Beasts | 270 + 30 breeding |
| Dragon Types | 10 standard + 2 ancient |
| Races/Factions | 15 |
| Holidays | 6 |
| Personal Events | 4 |

---

### TMX Map Files
- `template_all.tmx`
- `template_pokemon.tmx`
- `template_holiday.tmx`
- `template_overworld.tmx`
- `home.tmx`
- `house.tmx`
- `astral_spire.tmx`
- `lpc_church.tmx`
- `ring_clearing.tmx`
- `swamp_witch.tmx`
- `drow_cave.tmx`
- `lloth_realm.tmx`
- `volcano.tmx`
- `castle.tmx`
- `crystal_towers.tmx`
- `haunted_house.tmx`
- `haunted_mansion.tmx`
- `haunted_prison.tmx`
- `graveyard.tmx`
- `crypt.tmx`
- `mausoleum.tmx`
- `moon_red.tmx`
- `moon_orange.tmx`
- `moon_yellow.tmx`
- `moon_green.tmx`
- `moon_blue.tmx`
- `moon_indigo.tmx`
- `moon_violet.tmx`
- `pokemon_gym.tmx`

---

### Map Layer Structure
Every TMX map follows the Andor's Trail template exactly:
```
Tilesets: 60 AT tilesets (map_bed_1 … map_transition_5)
Tile Layers (base64+zlib encoded, all blank):
  Base, Ground, Objects, Objects_replace, Above, Above_replace, Top, Walkable
Object Layers — Mapevents, Spawn, Keys, Replace (+ extra named groups)
```

---

### Integration Checklist
1. Copy all `.tmx` files to your `maps/` directory
2. Copy all `.json` files to `res/raw/` in your game source
3. Add `values/loadresources.xml` array entries to your resource loading list
4. Required tileset images: see AT_TILESETS list in the generator source

---

### Content File Naming Convention (per AT spec)
- Items:           `itemlist_<name>.json`
- Monsters/NPCs:   `monsterlist_<name>.json`
- Conversations:   `conversationlist_<name>.json`
- Quests:          `questlist_<name>.json`
- Actor conditions:`actorconditions_<name>.json`
- Droplists:       `droplists_<name>.json`
- Item categories: `itemcategories_<name>.json`

---

*Andor's Trail Extended Content Pack v5 — Generated May 2026*
